package testbase;

import java.time.Duration;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import utilities.LoggerUtil;

public class BaseClass {

	public WebDriver driver;
	Logger log = LoggerUtil.getLogger(BaseClass.class);

	@BeforeClass
	public void setup() {
		log.info("Starting Test Execution");
		driver = new ChromeDriver();
		log.info("Browser Launched");
		// driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		driver.manage().window().maximize();
		driver.get("file:///C:/Users/Neha/OneDrive/Desktop/test.html");
		log.info("Navigated to URL");

	}

	@AfterClass
	public void tearDown() {
		driver.quit();
		log.info("Browser Closed");
		log.error("Test Error");

	}

	//Custom Method for Random String Generator
	public String randomString() {

		String generatedstring = RandomStringUtils.randomAlphabetic(5);
		return generatedstring;
	}

	//Custom Method for Random Number Generator
	public String randonNumber() {
		String generatednumber = RandomStringUtils.randomNumeric(10);
		return generatednumber;

	}
	
	// Custom Method for Random AlphaNumeric
	public String randomAlphaNumeric() {
		String generatedstring = RandomStringUtils.randomAlphabetic(3);
		String generatednumber = RandomStringUtils.randomNumeric(3);
		return (generatedstring+"@"+generatednumber);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
