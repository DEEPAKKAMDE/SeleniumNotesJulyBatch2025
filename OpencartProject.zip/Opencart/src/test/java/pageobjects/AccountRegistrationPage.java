package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountRegistrationPage extends BasePage {

	public AccountRegistrationPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//input[@id='firstname']")
	WebElement txtFirtName;

	@FindBy(xpath = "//input[@id='lastname']")
	WebElement txtLastName;

	@FindBy(xpath = "//input[@id='email']")
	WebElement txtEmail;
	
	@FindBy(xpath = "//input[@id='telephone']")
	WebElement txtPhone;

	@FindBy(xpath = "//input[@id='password']")
	WebElement txtPassword;
	
	@FindBy(xpath = "//input[@id='confirm']")
	WebElement txtCnfPassword;

	@FindBy(xpath = "//input[@name='newsletter']")
	WebElement chkNewsLetter;

	@FindBy(xpath = "//input[@name='agree']")
	WebElement btnContinue;

	public void setFirstName(String fname) {
		txtFirtName.sendKeys(fname);
	}

	public void setLastName(String lname) {
		txtLastName.sendKeys(lname);
	}

	public void setEmail(String email) {
		txtEmail.sendKeys(email);
	}
	
	
	public void setTelephone(String phone) {
		txtPhone.sendKeys(phone);
	}
	
	
	public void setPassword(String pwd) {
		txtPassword.sendKeys(pwd);
	}
	
	public void setConfirmPassword(String pwd) {
		txtCnfPassword.sendKeys(pwd);
	}

	public void clickNewsLetter() {
		chkNewsLetter.click();
	}

	public void clickAgree() {
		btnContinue.click();
	}

}
